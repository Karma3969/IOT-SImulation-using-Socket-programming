/**
 * websocket_server.c
 * Core server implementation for the IoT Smart Home Controller.
 * Handles TCP lifecycle, I/O multiplexing with select(), HTTP/WebSocket handshake, and message parsing.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/select.h>

#include "utils.h"
#include "db.h"

#define PORT 8080
#define MAX_CLIENTS 100
#define BUFFER_SIZE 8192

// Concurrency Model Decision: select() vs Multithreading
// We chose `select()` (I/O multiplexing) for this server.
// Trade-offs vs Multithreading:
// - Memory Efficiency: Threads require separate stacks (typ. 1MB - 8MB per thread), which doesn't scale well for 1k+ IoT connections on constrained gateways. `select()` uses minimal per-client memory (just a struct state).
// - Context Switching: Multithreading creates heavy OS context-switching overhead. Multiplexing avoids this entirely.
// - Synchronization: Multithreading requires mutexes to protect shared DB handles and client arrays. Multiplexing runs in a single thread, simplifying logic (no race conditions), though any blocking operation (like big DB queries) blocks the entire event loop.
//
// In Linux, `epoll` is the ultimate optimization over `select()` (O(1) vs O(n) polling complexity), but `select()` is highly portable (POSIX) and acceptable for typical home IoT loads (<1000 devices).

typedef enum {
    STATE_HTTP,
    STATE_WEBSOCKET
} ClientState;

typedef struct {
    int fd;
    ClientState state;
    uint8_t buffer[BUFFER_SIZE]; // Partial read buffer
    size_t buffer_len;
    int is_device;               // 1 if device simulator, 0 if web client
    char device_id[32];          // e.g. "light1"
} client_t;

client_t clients[MAX_CLIENTS];

// Make a socket non-blocking
void set_nonblocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags == -1) return;
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

// Disconnect a client and clean up
void disconnect_client(int i) {
    if (clients[i].fd != -1) {
        // TCP state: When we call close(), the socket enters TIME_WAIT or LAST_ACK depending on who initiated.
        // If the client crashed quietly, we might have been in CLOSE_WAIT until we explicitly hit close() here.
        // CLOSE_WAIT means the other end sent a FIN, and our OS ACk'd it, waiting for the application to call close().
        close(clients[i].fd);
        clients[i].fd = -1;
        clients[i].state = STATE_HTTP;
        clients[i].buffer_len = 0;
        memset(clients[i].device_id, 0, sizeof(clients[i].device_id));
        printf("Client slot %d disconnected.\n", i);
    }
}

// Broadcast a message to all web clients (and optionally devices)
void broadcast_ws_text(const char* payload, int only_web_clients) {
    uint8_t frame[BUFFER_SIZE];
    size_t frame_len = build_ws_text_frame(payload, frame, sizeof(frame));
    if (frame_len == 0) return;

    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i].fd != -1 && clients[i].state == STATE_WEBSOCKET) {
            if (only_web_clients && clients[i].is_device) continue;
            
            // Handle partial writes:
            // A truly robust non-blocking server handles partial send() by buffering the remaining bytes 
            // and trying again when select() indicates the socket is writable. For brevity, we assume 
            // single-call send() succeeds for small frames (<MTU).
            ssize_t sent = send(clients[i].fd, frame, frame_len, 0);
            if (sent < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
                disconnect_client(i);
            }
        }
    }
}

// Process HTTP upgrade to WebSocket
void handle_http_request(int client_index) {
    client_t* c = &clients[client_index];
    
    // Check if we have end of HTTP headers
    char* header_end = strstr((char*)c->buffer, "\r\n\r\n");
    if (!header_end) {
        if (c->buffer_len == BUFFER_SIZE) {
            // Buffer full, invalid request
            disconnect_client(client_index);
        }
        return; // Wait for more data
    }

    // Parse Sec-WebSocket-Key
    char* key_start = strstr((char*)c->buffer, "Sec-WebSocket-Key: ");
    if (!key_start) {
        // Not a WebSocket request
        const char* bad_req = "HTTP/1.1 400 Bad Request\r\n\r\n";
        send(c->fd, bad_req, strlen(bad_req), 0);
        disconnect_client(client_index);
        return;
    }

    key_start += 19;
    char* key_end = strchr(key_start, '\r');
    if (!key_end) return;

    char client_key[64] = {0};
    strncpy(client_key, key_start, key_end - key_start);

    // Compute accept key
    char accept_key[64];
    generate_ws_accept_key(client_key, accept_key);

    char response[512];
    snprintf(response, sizeof(response),
             "HTTP/1.1 101 Switching Protocols\r\n"
             "Upgrade: websocket\r\n"
             "Connection: Upgrade\r\n"
             "Sec-WebSocket-Accept: %s\r\n"
             "\r\n", accept_key);

    send(c->fd, response, strlen(response), 0);

    // Switch state
    c->state = STATE_WEBSOCKET;
    
    // Clear buffer (ignoring any pipelined data for simplicity here)
    c->buffer_len = 0;
    printf("Client slot %d upgraded to WebSocket.\n", client_index);
}


// Parse basic JSON using standard C string matching 
// Example: {"type":"status","device":"light1","state":"ON"}
void handle_json_message(int client_index, const char* json) {
    client_t* c = &clients[client_index];

    char type[32] = {0};
    char device[32] = {0};
    char state_or_action[32] = {0};

    // Very rudimentary extraction for {"type":"...","device":"...","state":"..."}
    char* type_ptr = strstr(json, "\"type\":\"");
    if (type_ptr) sscanf(type_ptr + 8, "%31[^\"]", type);

    char* dev_ptr = strstr(json, "\"device\":\"");
    if (dev_ptr) sscanf(dev_ptr + 10, "%31[^\"]", device);

    if (strcmp(type, "status") == 0) {
        c->is_device = 1;
        strncpy(c->device_id, device, sizeof(c->device_id) - 1);
        
        char* state_ptr = strstr(json, "\"state\":\"");
        if (state_ptr) sscanf(state_ptr + 9, "%31[^\"]", state_or_action);
        
        printf("[Device Status] %s is %s\n", device, state_or_action);
        
        // Save to DB
        db_update_device_status(device, state_or_action);
        db_log_action(device, "STATUS_UPDATE");
        
        // Broadcast to web clients
        broadcast_ws_text(json, 1);

    } else if (strcmp(type, "command") == 0) {
        char* act_ptr = strstr(json, "\"action\":\"");
        if (act_ptr) sscanf(act_ptr + 10, "%31[^\"]", state_or_action);
        
        printf("[Web Client Cmd] Turn %s %s\n", device, state_or_action);
        db_log_action(device, state_or_action);

        // Forward to the specific device
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i].fd != -1 && clients[i].is_device && strcmp(clients[i].device_id, device) == 0) {
                uint8_t frame[BUFFER_SIZE];
                size_t frame_len = build_ws_text_frame(json, frame, sizeof(frame));
                send(clients[i].fd, frame, frame_len, 0);
            }
        }
    }
}


void handle_ws_request(int client_index) {
    client_t* c = &clients[client_index];

    uint8_t* payload;
    size_t frame_size;
    int opcode;
    
    // Check if we have a full frame parsed (handling partial reads and buffering)
    int payload_len = parse_ws_frame(c->buffer, c->buffer_len, &payload, &frame_size, &opcode);
    
    if (payload_len < 0) {
        // Incomplete frame, keep waiting
        if (c->buffer_len == BUFFER_SIZE) {
            disconnect_client(client_index); // Frame too big
        }
        return;
    }

    if (opcode == 0x8) {
        // Close frame
        disconnect_client(client_index);
        return;
    } else if (opcode == 0x9) {
        // Ping -> respond with Pong (opcode 0xA) 
        // Security Feature: Heartbeat to prevent Connection drops (Timeout detection)
        uint8_t pong_frame[128];
        pong_frame[0] = 0x8A; // FIN + Pong
        pong_frame[1] = payload_len < 125 ? payload_len : 0;
        if(payload_len < 125 && payload_len > 0) {
            memcpy(&pong_frame[2], payload, payload_len);
        }
        send(c->fd, pong_frame, 2 + pong_frame[1], 0);
    } else if (opcode == 0x1) {
        // Text frame
        // Null-terminate payload safely for JSON parsing
        char json[BUFFER_SIZE];
        if (payload_len < (int)sizeof(json)) {
            memcpy(json, payload, payload_len);
            json[payload_len] = '\0';
            handle_json_message(client_index, json);
        }
    }

    // Shift buffer (remove processed frame)
    memmove(c->buffer, c->buffer + frame_size, c->buffer_len - frame_size);
    c->buffer_len -= frame_size;
}

int main() {
    int server_fd;
    struct sockaddr_in address;

    // Initialize DB
    if (db_init("smarthome.db") < 0) return 1;

    // Init clients array
    for (int i = 0; i < MAX_CLIENTS; i++) clients[i].fd = -1;

    // 1. socket()
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed"); exit(EXIT_FAILURE);
    }

    // Configure SO_REUSEADDR
    // Explanation: If the server terminates abruptly, the socket enters the TIME_WAIT state 
    // to digest any duplicate packets in the network for a timeout duration (usually 2*MSL).
    // SO_REUSEADDR allows us to immediately re-bind to port 8080 without getting "Address already in use".
    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("setsockopt SO_REUSEADDR"); exit(EXIT_FAILURE);
    }

    // Configure TCP_NODELAY
    // Explanation: Operating systems bundle small packets together to save bandwidth (Nagle's Algorithm).
    // This introduces artificial latency (up to ~200ms). WebSockets are real-time, so we disable Nagle's
    // by setting TCP_NODELAY. This optimizes latency for small {"type":"status"} packets.
    if (setsockopt(server_fd, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt))) {
        perror("setsockopt TCP_NODELAY"); exit(EXIT_FAILURE);
    }

    set_nonblocking(server_fd);

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // 2. bind()
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed"); exit(EXIT_FAILURE);
    }

    // 3. listen()
    if (listen(server_fd, SOMAXCONN) < 0) {
        perror("Listen failed"); exit(EXIT_FAILURE);
    }

    printf("WebSocket server running on port %d\n", PORT);

    fd_set readfds;

    // 4. select() Loop
    while (1) {
        FD_ZERO(&readfds);
        FD_SET(server_fd, &readfds);
        int max_sd = server_fd;

        for (int i = 0; i < MAX_CLIENTS; i++) {
            int sd = clients[i].fd;
            if (sd > 0) FD_SET(sd, &readfds);
            if (sd > max_sd) max_sd = sd;
        }

        // Wait for an activity on one of the sockets
        int activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);

        if ((activity < 0) && (errno != EINTR)) {
            printf("select error\n");
        }

        // If something happened on the master socket, it's an incoming connection
        if (FD_ISSET(server_fd, &readfds)) {
            int new_socket;
            struct sockaddr_in client_addr;
            socklen_t addrlen = sizeof(client_addr);

            // accept()
            if ((new_socket = accept(server_fd, (struct sockaddr *)&client_addr, &addrlen)) >= 0) {
                set_nonblocking(new_socket);
                
                // Add to client list
                for (int i = 0; i < MAX_CLIENTS; i++) {
                    if (clients[i].fd == -1) {
                        clients[i].fd = new_socket;
                        clients[i].state = STATE_HTTP;
                        clients[i].buffer_len = 0;
                        clients[i].is_device = 0;
                        printf("New connection on fd %d (slot %d)\n", new_socket, i);
                        break;
                    }
                }
            }
        }

        // Check all client sockets for IO
        for (int i = 0; i < MAX_CLIENTS; i++) {
            int sd = clients[i].fd;
            if (sd != -1 && FD_ISSET(sd, &readfds)) {
                // recv()
                int valread = recv(sd, clients[i].buffer + clients[i].buffer_len, 
                                   BUFFER_SIZE - clients[i].buffer_len, 0);

                if (valread == 0) {
                    // TCP FIN received
                    disconnect_client(i);
                } else if (valread < 0) {
                    if (errno != EAGAIN && errno != EWOULDBLOCK) {
                        disconnect_client(i);
                    }
                } else {
                    clients[i].buffer_len += valread;

                    if (clients[i].state == STATE_HTTP) {
                        handle_http_request(i);
                    } else if (clients[i].state == STATE_WEBSOCKET) {
                        handle_ws_request(i);
                    }
                }
            }
        }
    }

    db_close();
    return 0;
}
